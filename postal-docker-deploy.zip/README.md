# Postal Docker 部署工具包

请使用 `init.sh` 一键部署。